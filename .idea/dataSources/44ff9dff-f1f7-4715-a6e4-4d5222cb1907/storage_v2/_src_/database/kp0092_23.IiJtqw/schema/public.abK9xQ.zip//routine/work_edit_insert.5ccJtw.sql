create procedure work_edit_insert(item_id integer, ed_izm character varying, item_type integer, delivery boolean, item_name character varying, price integer, prod integer, amount integer, sklad integer)
    language plpgsql
as
$$
BEGIN
	insert into public.item_view values(item_id, ed_izm, item_type, delivery, item_name, price, prod);
	insert into public.have_view values(amount, sklad, item_id);
end;
$$;

alter procedure work_edit_insert(integer, varchar, integer, boolean, varchar, integer, integer, integer, integer) owner to st0092;

