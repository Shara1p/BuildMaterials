create view producer_item(item_name, amount, price, ed_izm, delivery, prod_name, phone_num) as
SELECT item.item_name,
       have.amount,
       item.price,
       item.ed_izm,
       item.delivery,
       producer.prod_name,
       producer.phone_num
FROM item
         LEFT JOIN producer ON producer.prod_id = item.prod
         LEFT JOIN have ON have.item_id = item.item_id;

alter table producer_item
    owner to st0092;

