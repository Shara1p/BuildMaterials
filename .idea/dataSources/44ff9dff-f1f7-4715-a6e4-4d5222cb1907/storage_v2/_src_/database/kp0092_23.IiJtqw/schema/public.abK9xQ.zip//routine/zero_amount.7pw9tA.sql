create function zero_amount()
    returns TABLE(item_name character varying, item_type integer, amount integer)
    language plpgsql
as
$$
begin
	return query
		select item.item_name, item.item_type, have.amount from have
		left join
		item on have.item_id = item.item_id where have.amount = 0;
end;
$$;

alter function zero_amount() owner to st0092;

