create function least_expensive(item_typ character varying)
    returns TABLE(item_id integer, ed_izm character varying, item_type integer, delivery boolean, item_name character varying, price integer, prod integer)
    language plpgsql
as
$$
begin
	return query select * from item where item.price = (select min(item.price) from item 
									 where item.item_type = (select item_type.type_id from item_type where type_name = item_typ));								 
end;
$$;

alter function least_expensive(varchar) owner to st0092;

