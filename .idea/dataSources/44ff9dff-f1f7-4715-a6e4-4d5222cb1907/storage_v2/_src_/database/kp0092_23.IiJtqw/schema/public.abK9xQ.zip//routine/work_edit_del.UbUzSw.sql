create procedure work_edit_del(id integer)
    language plpgsql
as
$$
BEGIN
	delete from public.have_view where have_view.item_id = id;
	delete from public.item_view where item_view.item_id = id;
end;
$$;

alter procedure work_edit_del(integer) owner to st0092;

