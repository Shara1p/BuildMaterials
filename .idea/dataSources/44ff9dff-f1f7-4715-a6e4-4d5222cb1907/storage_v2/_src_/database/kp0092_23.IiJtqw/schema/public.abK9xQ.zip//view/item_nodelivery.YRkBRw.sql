create view item_nodelivery(item_id, ed_izm, item_type, delivery, item_name, price, prod) as
SELECT item.item_id,
       item.ed_izm,
       item.item_type,
       item.delivery,
       item.item_name,
       item.price,
       item.prod
FROM item
WHERE item.delivery = false;

alter table item_nodelivery
    owner to st0092;

