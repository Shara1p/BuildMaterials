create procedure have_update(id integer, amountt integer)
    language plpgsql
as
$$
BEGIN
	update have_view set amount = amountt where have_view.item_id = id;
end;
$$;

alter procedure have_update(integer, integer) owner to st0092;

