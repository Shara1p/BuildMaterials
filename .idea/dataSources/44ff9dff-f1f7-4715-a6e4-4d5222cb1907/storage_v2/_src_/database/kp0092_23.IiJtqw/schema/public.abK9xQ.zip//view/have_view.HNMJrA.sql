create view have_view(amount, sklad, item_id) as
SELECT have.amount,
       have.sklad,
       have.item_id
FROM have;

alter table have_view
    owner to st0092;

