create view work_edit (item_id, ed_izm, item_type, delivery, item_name, price, prod, amount, sklad) as
SELECT item.item_id,
       item.ed_izm,
       item.item_type,
       item.delivery,
       item.item_name,
       item.price,
       item.prod,
       have.amount,
       have.sklad
FROM item
         LEFT JOIN have ON have.item_id = item.item_id;

alter table work_edit
    owner to st0092;

