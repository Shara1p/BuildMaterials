create view producer_type(type_name, item_type, prod_id, prod_name) as
SELECT item_type.type_name,
       item.item_type,
       producer.prod_id,
       producer.prod_name
FROM producer
         LEFT JOIN item ON producer.prod_id = item.prod
         LEFT JOIN item_type ON item.item_type = item_type.type_id;

alter table producer_type
    owner to st0092;

