create view item_view(item_id, ed_izm, item_type, delivery, item_name, price, prod) as
SELECT item.item_id,
       item.ed_izm,
       item.item_type,
       item.delivery,
       item.item_name,
       item.price,
       item.prod
FROM item;

alter table item_view
    owner to st0092;

grant select on item_view to kpuser23;

